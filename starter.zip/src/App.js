import React from 'react';
import './App.css';
import { BrowserRouter as Router, Switch, Route } from 'react-router-dom';
import Home from './pages/home';
import Term from './pages/term-insurance';

function App () {
  return (
      <Router basename="/starter">
        <>
          <Switch>
              <Route exact path='/' component={Home} />
              <Route path='/term-insurance' component={Term} />
          </Switch>
        </>
      </Router>
    );
}

export default App;