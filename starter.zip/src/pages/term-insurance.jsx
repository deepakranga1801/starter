import React from 'react';

function Term() {
      return (
         <>
            <nav className="navbar navbar-expand-lg fixed-top nav-scrolled navbar-dark" aria-label="Main navigation" style={{ 'background': '#fff' }}>
               <div className="container-fluid mx-lg-5 mx-md-5 mx-sm-5 mx-1">

                  <a href="/" className="navbar-brand d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">

                     <img src="assets/images/insuredaq-logo.png" className="d-block mx-lg-auto img-fluid"
                        alt="Logo" width="150" height="36" loading="lazy" /></a>

                  <button className="navbar-toggler p-0 border-0" type="button" data-bs-toggle="offcanvas"
                     aria-label="Toggle navigation">
                     <span className="navbar-toggler-icon"></span>
                  </button>

                  <div className="navbar-collapse offcanvas-collapse ps-5" id="navbarsExampleDefault">

                     <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item dropdown">
                           <a className="nav-link dropdown-toggle text-dark" href="/#" id="dropdown01" data-bs-toggle="dropdown"
                              aria-expanded="false">Insurance Products</a>
                           <ul className="dropdown-menu" aria-labelledby="dropdown01">
                              <li><a className="dropdown-item" href="index.html">A</a></li>
                              <li><a className="dropdown-item" href="index-2.html">B</a></li>
                           </ul>
                        </li>
                        <li className="nav-item dropdown">
                           <a className="nav-link dropdown-toggle text-dark" href="/#" id="dropdown02" data-bs-toggle="dropdown"
                              aria-expanded="false">Renew Your Policy</a>
                           <ul className="dropdown-menu" aria-labelledby="dropdown01">
                              <li><a className="dropdown-item" href="about-us.html">C</a></li>
                              <li><a className="dropdown-item" href="about-us-2.html">D</a></li>
                           </ul>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">File a Claim</a>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">Knowledge Center</a>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">Contact Us</a>
                        </li>
                     </ul>

                     <div className="text-end mt-5 mt-lg-0 mt-md-0 mt-sm-0">
                        <button type="button" className="btn btn-dark me-2">Become an Agent</button>
                     </div>

                  </div>

               </div>
            </nav>

            <div className="container col-xxl-8 pt-5">
               <div className="row align-items-center g-5 py-5 px-5">
                  <div className="col-lg-12">
                     <h1 className="display-5 mb-3" style={{ 'fontWeight': '400' }}>Let's find you <br />the&nbsp;
                        <span className="text-primary-color fw-bold mb-3">Term Insurance</span></h1>
                        <p>Term insurance is a life insurance policy that provides financial coverage to the beneficiary of the policy if the life insured dies during the active term of the policy. A term insurance plan provides life insurance cover against the fixed premium paid for specified "term" of the year. As a pure protection plan, term insurance policies offer higher insurance coverage at lower premium rates. For example, an individual can purchase 1 crore life cover at the lowest premium rate of Rs 490 per month.</p>
                  </div>
               </div>
            </div>

            <div className="container my-5">
               <div className="row flex-row-reverse flex-lg-row flex-md-row flex-sm-row align-items-center px-5">
                  <div className="col-12 col-lg-7 col-md-7 col-sm-7">
                     <img src="assets/images/insurance.png" className="d-block mx-lg-auto img-fluid" alt="" width="270" height="270" loading="lazy" />
                  </div>
                  <div className="col-12 col-lg-5 col-md-5 col-sm-5">
                     <div className="row px-5 py-5 form-bdr">
                     <h1 className="mb-4" style={{ 'fontWeight': '400','font-size': '1.5em','line-height': '1.4' }}>Get  
                        <span className="text-primary-color fw-bold mb-3">₹1 Cr. Life Cover</span> at just <span className="text-primary-color fw-bold mb-3">₹411/month*</span></h1>
                        <form>
                           <div className="form-floating mb-3">
                              <input type="text" className="form-control" id="floatingInput" placeholder="Deepak Kumar" />
                              <label htmlFor="floatingInput">Full Name</label>
                           </div>
                           <div className="form-floating mb-3">
                              <input type="email" className="form-control" id="floatingInput" placeholder="name@example.com" />
                              <label htmlFor="floatingInput">Email address</label>
                           </div>
                           <div className="form-floating">
                              <input type="text" className="form-control" id="floatingPassword" placeholder="+91982*******" />
                              <label htmlFor="floatingPassword">Mobile No.</label>
                           </div>
                           <div className="col-12 my-2">
                              <button type="submit" className="btn btn-dark mb-3">Send Now</button>
                           </div>
                        </form>
                     </div>
                  </div>
               </div>
            </div>

            <div className="container py-5">
               <div className="row d-flex">
                  <div className="col-3">
                     <nav id="navbar-example3" className="navbar navbar-light bg-light flex-column align-items-stretch p-3">
                        <a className="navbar-brand" href="#">Inquire Now</a>
                        <nav className="nav nav-pills flex-column">
                           <a className="nav-link" href="#item-1">- What Is Term Insurance?</a>
                           <a className="nav-link" href="#item-2">- Best Term Insurance Plans</a>
                           <a className="nav-link" href="#item-3">- Why Should You</a>
                           <a className="nav-link" href="#item-4">- Benefits</a>
                           <a className="nav-link" href="#item-5">- Key Features</a>
                           <a className="nav-link" href="#item-6">- Types of Term Plans</a>
                           <a className="nav-link" href="#item-7">- Compare Term Insurance Plans</a>
                           <a className="nav-link" href="#item-8">- Right Time to Buy</a>
                           <a className="nav-link" href="#item-9">- Premium</a>
                           <a className="nav-link" href="#item-10">- Buying Guide</a>
                           <a className="nav-link" href="#item-11">- Reasons to Buy</a>
                           <a className="nav-link" href="#item-12">- Who Should Buy</a>
                           <a className="nav-link" href="#item-13">- How Does a Term Plan Work?</a>
                           <a className="nav-link" href="#item-14">- Claim Process</a>
                           <a className="nav-link" href="#item-15">- What is not covered?</a>
                           <a className="nav-link" href="#item-16">- Government Term Insurance Schemes</a>
                        </nav>
                     </nav>
                  </div>
                  <div className="col-9">
                     <div data-bs-spy="scroll" data-bs-target="#navbar-example3" data-bs-offset="0" tabindex="0" className="px-5 tbl">

                        {/* What Is Term Insurance? */}

                        <h4 id="item-1" className="display-6 my-5" style={{'font-weight': '400'}}>What Is Term Insurance?</h4>
                        <p className="text-justify">Term insurance is a life insurance policy that provides financial coverage for a specific tenure. The term plan provides financial protection to the beneficiary of the policy in case of the unfortunate demise of the life assured during the policy tenure. A term insurance plan provides life insurance cover against the fixed premium paid for a specified "term" of the year.<br/><br/>
                        
                        A term plan not only offers financial security to your family but also is capable of fulfilling its future needs such as your child’s higher education, child’s marriage, etc.<br/><br/>
                        
                        Among all the life insurance products, Term life insurance offers the highest life coverage for the minimum premiums during the term of the policy. For example, an individual can buy a life cover of Rs. 1 Crore at a premium rate of minimum Rs. 490 per month. Some Insurance Companies also cover permanent or partial disability wherein the policyholder’s regular income is disrupted.<br/><br/>
                        
                        <b>Note:</b> In case of survival of the life insured the coverage at the earlier rate of premiums is not guaranteed after the expiry of the term insurance policy. The buyer has to either obtain extended coverage with different payment conditions or forgo the coverage entirely.</p>

                        {/* Best Term Insurance Plans In India */}
                        
                        <h4 id="item-2" className="display-6 my-5" style={{'font-weight': '400'}}>Best Term Insurance Plans In India</h4>
                        <p>
                           <div className="flex flex-col">
                              <div className="-my-2 overflow-x-auto sm:-mx-6 lg:-mx-8">
                                 <div className="py-2 align-middle inline-block min-w-full sm:px-6 lg:px-8">
                                    <div className="overflow-hidden border-b border-gray-200 sm:rounded-lg" style={{'boxShadow':'0 6px 16px rgb(52 105 203 / 16%)'}}>
                                       <table className="min-w-full divide-y divide-gray-200">
                                          <thead className="bg-gray-50">
                                             <tr>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Insurers
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Term Plan
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Claim Settlement Ratio
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Max Maturity Age
                                                </th>
                                                <th scope="col" className="px-6 py-3 text-left text-xs font-medium text-gray-500 uppercase tracking-wider">
                                                Premium (for a cover of 1 crore)
                                                </th>
                                             </tr>
                                          </thead>
                                          <tbody className="bg-white divide-y divide-gray-200">
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             Aditya Birla Sun Life Insurance                                                 
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                ABSLI LifeShield Plan                                                    
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                97.1%                                                  
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                75 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 623/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             Aegon Life                                                 
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                iTerm                                                    
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                96.5%                                                  
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                100 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 479/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             Canara HSBC OBC Life Insurance                                                
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                iSelect+ LumpSum                                                  
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                95.2%                                                 
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                99 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 480/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             EXIDE                                                
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Exide Life Smart                                                  
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                97%                                                 
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                55 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 926/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             Edelweiss Tokio                                               
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Zindagi Plus+ Lump sum                                                 
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                97.8%                                                
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                80 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 478/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             Future Generali                                               
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Future Generali Flexi Online Term-Lumpsum                                             
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                95.2%                                                
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                75 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 486/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             HDFC Life                                               
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Life Option                                             
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                99%                                                
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                85 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 709/month
                                                </td>
                                             </tr>
                                             <tr>
                                             <td className="px-6 py-4 whitespace-nowrap">
                                             ICICI Prudential                                              
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                iProtect Smart Lumpsum                                            
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                98.6%                                               
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                85 years
                                                </td>
                                                <td className="px-6 py-4 whitespace-nowrap">
                                                Rs. 647/month
                                                </td>
                                             </tr>
                                          </tbody>
                                       </table>
                                    </div>
                                 </div>
                              </div>
                           </div>
                        </p>

                        <p className="mt-4" style={{'fontSize':'14px'}}>Disclaimer: “InsureDaq does not endorse, rate or recommend any particular insurer or insurance product offered by an insurer.”</p>

                        {/* Why Should You Buy Term Insurance? */}

                        <h4 id="item-3" className="display-6 my-5" style={{'font-weight': '400'}}>Why Should You Buy Term Insurance?</h4>
                        <p>
                        There are various reasons to buy a term plan. However, here are the key and basic reasons that you must buy term insurance:<br/><br/>

                        <b>The Dependency of your Family:</b> You can use the term insurance money to meet the monthly expenses of your dependents and family when you’re not around. Moreover, it fulfils vital life goals such as education and the marriage of your child.<br/><br/>

                        <b>Protection of the Assets:</b> A term plan allows you to take loans for assets such as a car or a house. Nevertheless, if you’re not around, your dependents and family might be burdened with the repayment of loans. In such circumstances, your family can utilize the term insurance pay-out in paying off the outstanding debts.<br/><br/>

                        <b>Risks Related to Lifestyle:</b> Present-day lifestyle problems often lead to various ailments and diseases. Some term insurance Plan do not just safeguard your dependents and loved ones after the demise of the policyholder but also offer critical illness protection for a lifetime. This key feature pays on the diagnosis of some critical illnesses such as heart attack or cancer.
                        </p>

                        <h4 id="item-4" className="display-6 my-5" style={{'font-weight': '400'}}>Benefits of Term Insurance Plan</h4>
                        <p>
                        A term insurance policy is a must for every person and one cannot articulate its importance completely. Term insurance plans are the only life insurance products that are especially designed to solve the sole purpose of protection. Now that everyone knows, it covers death perils and risks; here are some other core benefits of term insurance Plan in India:<br/><br/>

                        <b>Safety for Loans and Liabilities:</b> A term insurance also aids in providing safety for the dependents from your fiscal liabilities such as loans or any other debts that you have.<br/><br/>

                        <b>Cover Critical illness:</b> ogether with offering life cover, a term insurance plan also offers protection against critical illness. For a tiny add-on premium amount, Critical Illness cover offers lump sum payment when any critical illness such as kidney failure, cancer, or heart attack, etc. is first detected. Online Term Insurance Plan also takes care of family in case of your disability or critical illness. It provides<br/>
                        <ul>
                           <li>- Supplementary income in case of loss of income due to accidental disability or illness.</li><br/>
                           <li>- Get a lump sum amount if diagnosed with critical illnesses.</li><br/>
                           <li>- Additional sum insured in case of accidental death.</li>
                        </ul>
                        <br/>

                        <b>Higher Sum Assured at Affordable Premiums:</b> One of the most alluring features of term insurance Plan is that the premiums are always the lowest, unlike the other life insurance products. Moreover, the sum assured offered under term Plan is relatively higher when compared to the premium amounts. Regular term insurance Plan, including TROP Plan, come with a 105% return on the premium benefit when the policy matures.<br/><br/>

                        <b>Tax Benefits:</b> Term insurance plan comes loaded with tax benefits on the term policy premiums paid. New-age term insurance Plan along with critical illness cover also provide some additional tax benefits on the premiums paid by the policyholder. One can also avail benefits subject to the conditions u/s 10(10D) on the amount that his/her family receives in the case of an untimely demise or unfortunate event.<br/><br/>

                        <b>Support in the case of Disability:</b> In some of the term plans, the insurance provider pays the future premiums in the case of permanent or total disability. Consequently, the policyholder’s life insurance cover continues even if s/he is not able to make payment of the premiums.<br/><br/>

                        <b>Add-on Protection:</b> So as to amplify the security of the family, a term insurance plan offers add-on pay-out in the case of an accident or untimely demise.<br/><br/>

                        <b>Death Benefits:</b> On the demise of the life assured during the tenure of the policy, the nominee/ beneficiary of the policy receives the total death benefit chosen at the time of commencement. Depending on the type of term insurance plan, the death benefit may stay the same over the whole tenure of the plan (standard term Plan), decrease (decreasing term Plan) or increase (increasing term Plan). The insurers provide various options of payment for the term insurance plan. These include a lump sum payment, lump-sum payment plus an annuity that may be monthly, quarterly or yearly, or simply annuities that are spread over the agreed number of years.<br/><br/>

                        <b>Maturity Benefits:</b> Term insurance plans don't come with any survival or maturity benefits. If one wants maturity benefits, then a TROP (Term Return of Premium) plan is suggested.<br/><br/>

                        <b>Survival Benefits :</b> A standard term plan does not have any survival benefits. However, the demand from investors has meant that various companies have opted to launch term insurance plans with survival benefits. Called Term Return of Premium (TROP) Plan, the term plan refunds the premium at the end of the term plan tenure if the insured person survives the period. The TROP plan is becoming popular with people who are looking for savings as well as insurance with their term plan.his term insurance plan has a higher premium than the standard term plan but has the advantage of assurance that the policyholder will get back the premium he or she paid to the life insurance company for the cover. Policyholders should read the insurance terms and conditions carefully to ensure they know the amount of money they will get back as survival benefits. Check out the term insurance policy that meets your needs with our term insurance comparison.
                        </p>

                        <h4 id="item-5" className="display-6 my-5" style={{'font-weight': '400'}}>Why Should You Buy Term Insurance?</h4>
                        <p></p>
                     </div>
                  </div>
               </div>
            </div>

            <div className="container-fluid footer-city">
               <div className="row align-items-center justify-content-center position-relative text-center my-5">
                  <div className="col-lg-12 position-absolute pos-cta">
                        <h3 className="display-5 text-center text-light pt-lg-5 mb-3" style={{ 'fontWeight': '400' }}>Join our exclusive network of <span className="text-primary-color fw-bold">Expert POS Advisors</span> <br />
                        spread across 100+ cities across India</h3>
                        <button type="button" className="btn btn-outline text-light my-5 me-2" style={{'borderColor':'#fff'}}>Become an Agent</button>
                  </div>
               </div>
            </div>

            <footer id="footer" className="footer-1">
               <div className="main-footer widgets-dark typo-light">
                  <div className="container mt-5">
                     <div className="row mx-1 mx-lg-5 mx-md-5 mx-sm-5">

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget subscribe no-box">
                              <h5 className="widget-title">InsureDaq<span></span></h5>
                              <p>The company registered 'Direct Broker' under the name <b>Analah Insurance Pvt Ltd</b>. It's a part of Analah Group Companies. Analah Capital is a Global Tech Based Distribution Platform for Financial Services, Real Estate, Taxation & Technology Solutions. </p>
                              <p><a href="mailto:contactus@insuredaq.com" title="">contactus@insuredaq.com</a></p>
                              <ul className="social-footer2">
                                 <li><a title="Facebook" href="https://www.facebook.com/InsureDaq-101973032048133"> <i className="fa fa-facebook-square mr-1 fs-4" aria-hidden="true"></i></a> </li>
                                 <li><a title="Twitter" href="https://twitter.com/InsureDaq"> <i className="fab fa-twitter-square fs-4" aria-hidden="true"></i></a> </li>
                                 <li><a title="Instagram" href="https://instagram.com/insuredaq"> <i className="fab fa-instagram-square fs-4" aria-hidden="true"></i></a> </li>
                                 <li><a title="Linkedin" href="https://www.linkedin.com/company/insuredaq/"> <i className="fab fa-linkedin fs-4" aria-hidden="true"></i> </a>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget no-box">
                              <h5 className="widget-title">General Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Car Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Bike Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Motor Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Travel Insurance</a></div>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget no-box">
                              <h5 className="widget-title">Life Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Term Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Spouse Term Plan</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Return of Premium</a></div>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">

                        <div className="widget no-box">
                              <h5 className="widget-title">Health Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Health Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">1 Cr Health Cover</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Family Health Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Corona Insurance</a></div>
                                 </li>
                              </ul>
                           </div>

                        </div>
                     </div>
                  </div>
               </div>

               <div className="footer-copyright">
                  <div className="container">
                     <div className="row mx-1 mx-sm-5 mx-md-5 mx-lg-5">

                        <div className="col-md-12 mt-3">
                           <p>Copyright © 2021 Insuredaq. All rights reserved.</p>
                        </div>

                        <div className="col-md-12 text-center mt-3">
                           <a className="text-white" data-bs-toggle="collapse" href="#disclaimertext" role="button" aria-expanded="false" aria-controls="disclaimertext">
                              Legal<br /><i className="fas fa-angle-double-down" aria-hidden="true"></i>
                           </a>

                           <div className="collapse" id="disclaimertext">
                              <div className="row d-flex justify-content-center mt-5">
                                 <div className="col">
                                    <p>CIN: </p>
                                 </div>
                                 <div className="col">
                                    <p>IRDAI Registration No: </p>
                                 </div>
                                 <div className="col">
                                    <p>Category: Life / Non-Life Insurance</p>
                                 </div>
                              </div>
                              <hr/>
                              <div className="row d-flex justify-content-center text-light">
                                 <div className="col">Disclaimers</div>
                                 <div className="col">Disclosures</div>
                                 <div className="col">Terms and Conditions</div>
                                 <div className="col">Privacy Policy</div>
                              </div>
                              <hr/>
                              <div className="text-white my-5">
                                 <p>*Discount is offered by the Insurance company as approved by IRDAI for the product under File & Use guidelines</p>
                              </div>
                           </div>
                        </div>

                     </div>
                  </div>
               </div>
            </footer>
         </>
      );
}
export default Term;