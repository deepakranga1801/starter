import React from 'react';

function Home () {
      return (
         <>
            <nav className="navbar navbar-expand-lg fixed-top nav-scrolled navbar-dark" aria-label="Main navigation" style={{ 'background': '#fff' }}>
               <div className="container-fluid mx-lg-5 mx-md-5 mx-sm-5 mx-1">

                  <a href="/" className="navbar-brand d-flex align-items-center mb-2 mb-lg-0 text-white text-decoration-none">

                     <img src="assets/images/insuredaq-logo.png" className="d-block mx-lg-auto img-fluid"
                        alt="Logo" width="150" height="36" loading="lazy" /></a>

                  <button className="navbar-toggler p-0 border-0" type="button" data-bs-toggle="offcanvas"
                     aria-label="Toggle navigation">
                     <span className="navbar-toggler-icon"></span>
                  </button>

                  <div className="navbar-collapse offcanvas-collapse ps-5" id="navbarsExampleDefault">

                     <ul className="navbar-nav me-auto mb-2 mb-lg-0">
                        <li className="nav-item dropdown">
                           <a className="nav-link dropdown-toggle text-dark" href="/#" id="dropdown01" data-bs-toggle="dropdown"
                              aria-expanded="false">Insurance Products</a>
                           <ul className="dropdown-menu" aria-labelledby="dropdown01">
                              <li><a className="dropdown-item" href="index.html">A</a></li>
                              <li><a className="dropdown-item" href="index-2.html">B</a></li>
                           </ul>
                        </li>
                        <li className="nav-item dropdown">
                           <a className="nav-link dropdown-toggle text-dark" href="/#" id="dropdown02" data-bs-toggle="dropdown"
                              aria-expanded="false">Renew Your Policy</a>
                           <ul className="dropdown-menu" aria-labelledby="dropdown01">
                              <li><a className="dropdown-item" href="about-us.html">C</a></li>
                              <li><a className="dropdown-item" href="about-us-2.html">D</a></li>
                           </ul>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">File a Claim</a>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">Knowledge Center</a>
                        </li>
                        <li className="nav-item">
                           <a className="nav-link text-dark" href="/#" aria-expanded="false">Contact Us</a>
                        </li>
                     </ul>

                     <div className="text-end mt-5 mt-lg-0 mt-md-0 mt-sm-0">
                        <button type="button" className="btn btn-dark me-2">Become an Agent</button>
                     </div>

                  </div>

               </div>
            </nav>

            <div className="container col-xxl-8 pt-5">
               <div className="row flex-lg-row-reverse align-items-center g-5 py-5 px-5">
                  <div className="col-10 col-sm-8 col-lg-6">
                     <img src="assets/images/insurance.png" className="d-block mx-lg-auto img-fluid" alt="" width="270" height="270" loading="lazy" />
                  </div>
                  <div className="col-lg-6">
                     <h1 className="display-5 mb-3" style={{ 'fontWeight': '400' }}>Let's find you <br />the&nbsp;
                        <span className="text-primary-color fw-bold mb-3">Best Insurance</span></h1>
                     <div className="d-flex align-items-center my-4">
                        <p style={{ 'fontWeight': '500' }}>LICENSED BY </p><img src="assets/images/irdai.png" alt="irdai" width="140" />
                     </div>
                  </div>
               </div>
            </div>

            <div className="container col-xxl-8">
               <div className="row row-cols-2 row-cols-lg-5 g-2 g-lg-3 px-5">
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-umbrella"></i>
                        <p>Term Life<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-heartbeat"></i>
                        <p>Health<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-car"></i>
                        <p>Car<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-motorcycle"></i>
                        <p>2 Wheeler<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-users"></i>
                        <p>Family Health<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-baby"></i>
                        <p>Child Savings<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-suitcase-rolling"></i>
                        <p>Travel<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-house-user"></i>
                        <p>Retirement<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-rupee-sign"></i>
                        <p>1 Cr Health<br />Insurance</p>
                     </div>
                  </div>
                  <div className="col">
                     <div className="p-3 border text-center hmprd">
                        <i className="fas fa-street-view"></i>
                        <p>Saral Jeevan<br />Bima</p>
                     </div>
                  </div>
               </div>
            </div>

            <div className="container-fluid py-16 px-24 my-16" style={{ 'background': '#f7f9ff' }}>
               <div className="cards">
                  <article className="card card--1">
                     <div className="card__img"></div>
                     <a href="/#" className="card_link">
                        <div className="card__img--hover"></div>
                     </a>
                     <div className="card__info">
                        <span className="card__category">Health Insurance</span>
                        <h3 className="card__title">Protect yourself & your family against Covid-19</h3>
                     </div>
                  </article>

                  <article className="card card--2">
                     <div className="card__img"></div>
                     <a href="/#" className="card_link">
                        <div className="card__img--hover"></div>
                     </a>
                     <div className="card__info">
                        <span className="card__category">Investment Plans</span>
                        <h3 className="card__title">Invest ₹ 5 k per month & get ₹ 65 L in return</h3>
                     </div>
                  </article>

                  <article className="card card--3">
                     <div className="card__img"></div>
                     <a href="/#" className="card_link">
                        <div className="card__img--hover"></div>
                     </a>
                     <div className="card__info">
                        <span className="card__category">Home Insurance</span>
                        <h3 className="card__title">Protect ₹ 50L property & ₹ 20L worth contents at ₹ 222/month</h3>
                     </div>
                  </article>

                  <article className="card card--4">
                     <div className="card__img"></div>
                     <a href="/#" className="card_link">
                        <div className="card__img--hover"></div>
                     </a>
                     <div className="card__info">
                        <span className="card__category">Ask Us</span>
                        <h3 className="card__title">Got a question about insurance?  Write to us at contactus@insuredaq.com</h3>
                     </div>
                  </article>
               </div>
            </div>

            <div className="container my-5 mx-5">
               <div className="row align-items-center">
                  <div className="col-lg-6 col-md-6 text-center text-md-start">
                     <img src="assets/images/home-feature.png" alt="" className="pt-5 pb-2 mb-3 mx-5" width="80" height="80" />
                     <h3 className="display-5 mb-3 mx-5" style={{ 'fontWeight': '400' }}>What makes&nbsp;
                        <span className="text-primary-color fw-bold">Insuredaq</span><br /> the best place to buy <br />insurance in India?</h3>
                  </div>

                  <div className="col-lg-6 col-md-6 bg-position-center bg-repeat-0">
                     <div className="mx-5 my-lg-48 my-md-48 my-sm-48" style={{ 'maxWidth': '610px' }}>
                        <div className="row align-items-center">
                           <div className="col-sm-6">
                              <div className="rounded-3 p-4 mb-grid-gutter text-center text-sm-start mb-5 service-feature" style={{ 'background': '#edf1f7', 'boxShadow': '0 6px 16px rgb(52 105 203 / 16%)' }}>
                                 <i className="fas fa-shopping-cart d-inline-block mb-4 mt-2" style={{ 'fontSize': 'xx-large' }}></i>
                                 <h3 className="h5 mb-2 text-secondary-color fw-bold title">50+ Lacs</h3>
                                 <p className="fs-sm">Customers trust us & have bought their insurance on Insuredaq</p>
                              </div>

                              <div className="rounded-3 p-4 mb-grid-gutter text-center text-sm-start mb-5 service-feature" style={{ 'background': '#edf1f7', 'boxShadow': '0 6px 16px rgb(52 105 203 / 16%)' }}>
                                 <i className="fab fa-searchengin d-inline-block mb-4 mt-2" style={{ 'fontSize': 'xx-large' }}></i>
                                 <h3 className="h5 mb-2 text-secondary-color fw-bold title">30+ insurers</h3>
                                 <p className="fs-sm">Partnered with us so that you can compare easily & transparently</p>
                              </div>
                           </div>

                           <div className="col-sm-6 pt-32">
                              <div className="rounded-3 p-4 mb-grid-gutter text-center text-sm-start mb-5 service-feature" style={{ 'background': '#edf1f7', 'boxShadow': '0 6px 16px rgb(52 105 203 / 16%)' }}>
                                 <i className="fas fa-money-bill-wave d-inline-block mb-4 mt-2" style={{ 'fontSize': 'xx-large' }}></i>
                                 <h3 className="h5 mb-2 text-secondary-color fw-bold title">Lowest Price</h3>
                                 <p className="fs-sm">Guaranteed for all insurance plans available online</p>
                              </div>

                              <div className="rounded-3 p-4 mb-grid-gutter text-center text-sm-start mb-5 service-feature" style={{ 'background': '#edf1f7', 'boxShadow': '0 6px 16px rgb(52 105 203 / 16%)' }}>
                                 <i className="fas fa-user-shield d-inline-block mb-4 mt-2" style={{ 'fontSize': 'xx-large' }}></i>
                                 <h3 className="h5 mb-2 text-secondary-color fw-bold title">Claims</h3>
                                 <p className="fs-sm">Support built in with every policy for help, when you need it the most</p>
                              </div>
                           </div>
                        </div>
                     </div>
                  </div>
               </div>
            </div>

            <div className="container my-16">
               <div className="row align-items-center justify-content-center text-center my-5">
                  <div className="col-lg-12">
                     <div className="text-center">
                        <h3 className="display-5 text-center pt-lg-5 mb-3" style={{ 'fontWeight': '400' }}><span className="text-primary-color fw-bold">Leading Insurers</span> <br />
                        For your Financial Freedom</h3>
                     </div>
                  </div>
               </div>
               <div className="row lg:mx-28 md:mx-28 sm:mx-16 my-3">
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/aditya-birla-life-insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/AEGON_logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/aviva-life-insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/bajaj-life-insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/Care_health_insurance_logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/digit.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/edelweiss.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/HDFC_Life_Logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/icici-lombard-general-insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/Kotak-Life-logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/Max_Life_Insurance_logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/nia-logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/pnb-metlife-insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/Reliance-General-Insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/sbi_life.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/SBI-general-logo.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/Star_Health_and_Allied_Insurance.png" className="plogo" alt="" />
                  </div>
                  <div className="col-4 col-lg-2 col-md-2 col-sm-2 pt-3">
                     <img src="assets/images/logo/tata-aia.png" className="plogo" alt="" />
                  </div>
               </div>
            </div>

            <div className="container-fluid footer-city">
               <div className="row align-items-center justify-content-center position-relative text-center my-5">
                  <div className="col-lg-12 position-absolute pos-cta">
                        <h3 className="display-5 text-center text-light pt-lg-5 mb-3" style={{ 'fontWeight': '400' }}>Join our exclusive network of <span className="text-primary-color fw-bold">Expert POS Advisors</span> <br />
                        spread across 100+ cities across India</h3>
                        <button type="button" className="btn btn-outline text-light my-5 me-2" style={{'borderColor':'#fff'}}>Become an Agent</button>
                  </div>
               </div>
            </div>

            <footer id="footer" className="footer-1">
               <div className="main-footer widgets-dark typo-light">
                  <div className="container mt-5">
                     <div className="row mx-1 mx-lg-5 mx-md-5 mx-sm-5">

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget subscribe no-box">
                              <h5 className="widget-title">InsureDaq<span></span></h5>
                              <p>The company registered 'Direct Broker' under the name <b>Analah Insurance Pvt Ltd</b>. It's a part of Analah Group Companies. Analah Capital is a Global Tech Based Distribution Platform for Financial Services, Real Estate, Taxation & Technology Solutions. </p>
                              <p><a href="mailto:contactus@insuredaq.com" title="">contactus@insuredaq.com</a></p>
                              <ul className="social-footer2">
                                 <li><a title="Facebook" href="https://www.facebook.com/InsureDaq-101973032048133"> <i className="fa fa-facebook-square mr-1 fs-4" aria-hidden="true"></i> </a></li>
                                 <li><a title="Twitter" href="https://twitter.com/InsureDaq"> <i className="fab fa-twitter-square fs-4" aria-hidden="true"></i> </a></li>
                                 <li><a title="Instagram" href="https://instagram.com/insuredaq"> <i className="fab fa-instagram-square fs-4" aria-hidden="true"></i> </a></li>
                                 <li><a title="Linkedin" href="https://www.linkedin.com/company/insuredaq/"> <i className="fab fa-linkedin fs-4" aria-hidden="true"></i> </a>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget no-box">
                              <h5 className="widget-title">General Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Car Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Bike Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Motor Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Travel Insurance</a></div>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">
                           <div className="widget no-box">
                              <h5 className="widget-title">Life Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Term Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Spouse Term Plan</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Return of Premium</a></div>
                                 </li>
                              </ul>
                           </div>
                        </div>

                        <div className="col-xs-12 col-sm-6 col-md-3">

                        <div className="widget no-box">
                              <h5 className="widget-title">Health Insurance<span></span></h5>
                              <ul className="thumbnail-widget">
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Health Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">1 Cr Health Cover</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Family Health Insurance</a></div>
                                 </li>
                                 <li className="d-flex">
                                    <div className="thumb-content"><a href="/#">Corona Insurance</a></div>
                                 </li>
                              </ul>
                           </div>

                        </div>
                     </div>
                  </div>
               </div>

               <div className="footer-copyright">
                  <div className="container">
                     <div className="row mx-1 mx-sm-5 mx-md-5 mx-lg-5">

                        <div className="col-md-12 mt-3">
                           <p>Copyright © 2021 Insuredaq. All rights reserved.</p>
                        </div>

                        <div className="col-md-12 text-center mt-3">
                           <a className="text-white" data-bs-toggle="collapse" href="#disclaimertext" role="button" aria-expanded="false" aria-controls="disclaimertext">
                              Legal<br /><i className="fas fa-angle-double-down" aria-hidden="true"></i>
                           </a>

                           <div className="collapse" id="disclaimertext">
                              <div className="row d-flex justify-content-center mt-5">
                                 <div className="col">
                                    <p>CIN: </p>
                                 </div>
                                 <div className="col">
                                    <p>IRDAI Registration No: </p>
                                 </div>
                                 <div className="col">
                                    <p>Category: Life / Non-Life Insurance</p>
                                 </div>
                              </div>
                              <hr/>
                              <div className="row d-flex justify-content-center text-light">
                                 <div className="col">Disclaimers</div>
                                 <div className="col">Disclosures</div>
                                 <div className="col">Terms and Conditions</div>
                                 <div className="col">Privacy Policy</div>
                              </div>
                              <hr/>
                              <div className="text-white my-5">
                                 <p>*Discount is offered by the Insurance company as approved by IRDAI for the product under File & Use guidelines</p>
                              </div>
                           </div>
                        </div>

                     </div>
                  </div>
               </div>
            </footer>
         </>
      );
}
export default Home;